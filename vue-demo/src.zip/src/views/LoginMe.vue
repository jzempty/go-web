<template>
  <div class="login-container">
    <el-form 
    :inline="true" 
    :model="loginForm" 
    status-icon
    label-width="100px" 
    ref="form"
    :rules = "rules"
    margin="0 auto"
    class="login-form">
      <div class="LoginMes">登陆页面</div>

      <el-form-item label="用户名" size ="30px" prop="username">
        <el-input v-model="loginForm.username" placeholder="请输入用户名"></el-input>
      </el-form-item>

      <el-form-item label="密码" aria-setsize="30px" prop="password">
        <el-input type="password" v-model="loginForm.password" placeholder="请输入密码" autocomplete="off" maxlength="16"></el-input>
      </el-form-item>

      <el-form-item label="身份" prop="roleID">
        <div style="text-align: center">
        <el-radio v-model="loginForm.identity"  label="0">管理员</el-radio>
        <el-radio v-model="loginForm.identity"  label="1">学生</el-radio>
        <el-radio v-model="loginForm.identity"  label="2">教师</el-radio>
        </div>
      </el-form-item>

      <el-form-item style="text-align: center">
        <el-button type="primary" @click = "onsubmit" >登录</el-button>
        <el-button type= "success" @click = "register">注册</el-button>
      </el-form-item>

      
      <el-row style="text-align: center">
        <el-button type="info" plain @click="changePass" >忘记密码</el-button>  
        </el-row>
        <el-dialog 
          title="修改密码" 
          :visible.sync="changeVisible" 
          width="30%">
            <el-form ref="form" :model="changeForm" label-width="80px">
              //绑定的模型和登录的一样的话，点击弹窗就会记录有用户名和旧密码
              <el-form-item label="学号">
                  <el-input v-model="changeForm.username"></el-input>
                </el-form-item>

                <el-form-item label="旧密码">
                  <el-input v-model="changeForm.oldpassword"></el-input>
                </el-form-item>
                
                <el-form-item label="新密码">
                  <el-input v-model="changeForm.newpassword"></el-input>
                </el-form-item>

                <el-form-item label="确认新密码" type="password">
                  <el-input v-model="changeForm.comfirmpassword"></el-input>
                </el-form-item>

                <el-form-item>
                    <el-button type="primary" @click="changePass">提交</el-button>
                    <el-button @click="changeVisible = false">取消</el-button>
                </el-form-item>

            </el-form>
        </el-dialog>
      

    </el-form>
  </div>
</template>

<script>

import axios from 'axios'
  export default {
    name:'LoginMe',
    
    data() {
      return {
        changeVisible:false,
        changeForm:{
          username:'',
          oldpassword:'',
          newpassword:'',
          comfirmpassword:'',
        },
        loginForm: {
          username: '2015200002',
          password: '059219',
          identity:'1',
        },
        user:[{
          crousename:'',
            workname:'',
            deadline:'',
            submit:'',
        }],
        
        rules: {
        username: [{required: true, message: "请输入账号", trigger: "blur"},
        {
            validator: (rule, value, callback) => {
              //const reg = /^[\u4E00-\u9FA5A-Za-z0-9]+$/  //正则表达式 只能输入英文、汉字与数字
              const reg = /^[0-9]+$/
              if (!reg.test(value)) {
                callback(new Error('请勿输入特殊字符'))
              } else {
                callback()
              }
            }
          }
        ]
        },
        password:[
          {required: true, message: "请输入密码", trigger: "blur"},
          { min: 0, max: 16, message: '长度在 0 到 16个字符', trigger: 'blur' }
        ]
      }      
    },
    methods: {
      onsubmit() {
          //注册功能
          var _this = this
          
          axios({
            method:'post',
            url:'http://192.168.63.217:9999/do_login',
            data:_this.loginForm  
          }).then(res => res.data).then(res => {
          console.log(res)
          //登陆成功后，跳转到相应页面
          
          if (res.succession === 'true') {
            if (_this.loginForm.identity==0){
              window.location.href = "/admin";
            }else if(_this.loginForm.identity==1) {
              localStorage.setItem('user', JSON.stringify(res.data))
              console.log(JSON.stringify(res.data))
              console.log('user')
              window.location.href = "/stu";
           }else{
            localStorage.setItem('user', JSON.stringify(res.data))
              console.log(JSON.stringify(res.data))
              console.log('user')
              window.location.href = "/teacher";
            }
          } else if(res.code === 400){
            alert("该账号未注册")//注册失败，返回注册页面
          }else{
            alert("密码错误")
          }
        })
      },
      register(){
        this.$router.replace('/register')
      },
      changePass(){
        this.changeVisible = true;
        if (this.changeForm.newpassword != this.changeForm.comfirmpassword){
          alert("前后密码不正确");
        }
      },
    }
  }

</script>

<style lang="scss" scoped>
.LoginMes {
  text-align: center;
  color: #f3730a;
  font-family: 幼圆;
  font-size: 60px;
  margin-bottom: 40px;
}
.login-container {
  /*position: absolute;*/
  width: 100%;
  height: 100%;
  overflow: hidden;
  background-image: url('../assets/images/R.jpg');
  background-size: 100% 100%;
  //background-repeat: no-repeat;
}


.login-form {
  width: 480px;
  margin: 215px auto;
  background-color: rgb(143, 180, 229);
  padding: 50px;
  border-radius: 80px;
}
  
</style>

