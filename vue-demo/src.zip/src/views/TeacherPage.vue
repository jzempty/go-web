<template>
  <div id="TeacherPage" class="container">
    <div><h2>管理实验课程</h2></div>


        <el-row>
          <el-button type="primary" plain @click="AddCourse">创建课程</el-button>
          <el-button type="primary" plain @click="addAssignment">导入学生信息</el-button>
          
        </el-row>
        <el-dialog title="添加课程" :visible.sync="addcourse" width="50%">
          <el-form ref="form" :model="MgForm" label-width="120px" class="form-container">
            <el-form-item label="课程名称">
              <el-input v-model="MgForm.courseName" placeholder="请输入课程名称"></el-input>
            </el-form-item>
            <el-form-item label="开始时间">
              <el-date-picker v-model="MgForm.startDate" type="datetime" placeholder="选择日期时间"></el-date-picker>
            </el-form-item>
            <el-form-item label="课程学分">
              <el-date-picker v-model="MgForm.startDate" type="datetime" placeholder="请输入课程学分"></el-date-picker>
            </el-form-item>
            <el-form-item label="描述信息">
              <el-input v-model="MgForm.description" type="textarea" placeholder="请输入描述信息"></el-input>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="submitForm()">提交</el-button>
            </el-form-item>
          </el-form>
        </el-dialog>

    <el-form 
  :inline="true" 
  :model="msgfrom" 
  label-width="100px" 
  margin="0 auto"
  class="manage-form">
    <el-table :data="tableData" style="width: 100%" :row-class-name="tableRowClassName" @selection-change="handleSelectionChange" stripe>
            <el-table-column type="selection" width="55"></el-table-column>
            <el-table-column type="index" width="50"></el-table-column>

            <el-table-column prop="Coursename" label="课程名称" align="center"></el-table-column>

            <el-table-column prop="Courseteacher" label="任教老师" align="center"></el-table-column>
            
            <el-table-column prop="Starttime"  align="center"  label="开设时间"></el-table-column>

            <!--el-table-column prop="credit"  align="center"  label="课程学分"></el-table-column-->

            <el-table-column  prop=""  align="center"  label="导入学生信息">
                    <el-button type="success" round @click="getStudentList">导入学生信息</el-button>
            </el-table-column>

            <el-table-column  prop="Assignmentlist"  align="center"  label="作业列表">
                    <el-button type="primary" round @click="getAssignmentlist()">查看课程作业</el-button>
            </el-table-column>

            <el-table-column prop="operate" align="center" label="操作" width="200px">

                <el-row>
                    <el-button type="primary" @click="ChangeCourse" >修改</el-button>
                    <el-button type="danger" @click="DelCourse()">删除</el-button>
                </el-row>

                <el-dialog title="修改课程信息" :visible.sync="changecourseVisible" width="50%">
                    <el-form ref="form" :model="MgForm" label-width="120px" class="form-container">
                      <el-form-item label="课程名称">
                        <el-input v-model="MgForm.courseName" placeholder="请输入课程名称"></el-input>
                      </el-form-item>
                      <el-form-item label="开始时间">
                        <el-date-picker v-model="MgForm.startDate" type="datetime" placeholder="选择日期时间"></el-date-picker>
                      </el-form-item>
                      <el-form-item label="课程学分">
                        <el-date-picker v-model="MgForm.credit" type="datetime" placeholder="课程学分"></el-date-picker>
                      </el-form-item>
                      <el-form-item label="描述信息">
                        <el-input v-model="MgForm.description" type="textarea" placeholder="请输入描述信息"></el-input>
                      </el-form-item>
                      <el-form-item>
                        <el-button type="primary" @click="submitForm()">提交</el-button>
                        <el-button type="primary" @click="changecourseVisible = false">取消</el-button>
                      </el-form-item>
                    </el-form>
                </el-dialog>

            </el-table-column>

        </el-table>
    </el-form>

  </div>
</template>

<script>
import axios from 'axios';

export default {
  name:'TeacherPage',
  /*created() {
      const User = JSON.parse(localStorage.getItem('user'))
      console.log(" 哈哈哈  ",User)
      this.tableData = User
      this.user = User
      console.log(" 哈哈哈  ",this.tableData)
    },*/
  data() {
    return {
      addcourse:false,
      changecourseVisible:false,
      addAssignmentVisible:false,
      changeAssignmentVisible:false,
      msgfrom: {
        Coursename: '',
        Courseteacher: "",
        Assignmentlist:[],
        Starttime: '',
        Students:[]
        //可能这里需要修改  导入的是execl表
      },
      tableData: [
      {
        Coursename: '1',
        Courseteacher: "szj",
        Assignmentlist:[1],
        Starttime: '2023-2.20',
        credit:'',
        Students:[]
      },
      {
        Coursename: '2',
        Courseteacher: "szj",
        Assignmentlist:[1],
        Starttime: '2023-3.20',
        credit:'',
        Students:[]
      }
      ],
      MgForm: {
        courseName: '',
        startDate: '',
        credit:'',
        description: ''
      }
    }
  },
  methods: {
    getStudentList(){

    },
    getAssignmentlist(){      
      window.location.href="/assignment"
      /*axios({
        method:'post',
        url:'http://192.168.63.217:9999/CourseAssignmentQuery',
        //还需修改
        data:Coursename,
      }).then(res => res.data).then(res => {
        console.log(res)
        if(res.succession ==='true'){
          localStorage.setItem('assignment',JSON.stringify(res.data))
          localStorage.setItem('Coursename',this.Coursename)
          window.location.hraf="/assignment"
        }else{
          alert("获取失败")
        }
      }) */
    },
    AddCourse(){
      this.addcourse = true;
      axios({
        method:'post',
        url:'',
        data:this.MgForm
      }).then(res=>res.data).then(res=>{
        if (res.succession === 'true'){
                alert("删除成功")
            }else{
                alert("删除失败")
            }
      })
    },
    ChangeCourse(){
      this.changecourseVisible=true;
      //暂时为实现
    },
    DelCourse(Coursename){
      axios({
        method:'post',
        url:'',
        //未实现
        data:Coursename,
      }).then(res=>res.data).then(res=>{
        console.log(res)
        if(res.succession ==='true'){
          alert("成功删除")
        }else{
          alert("删除失败")
        }
      })
    },
    addAssignment(){
      this.addAssignmentVisible=true;
    },
    submitForm() {
      // 在这里提交表单数据，可以通过 API 发送请求给后端
      console.log(this.form)
    }
  }
}
</script>


<style scoped>
.container {
  max-width: 1200px;
  
  margin: 0 auto;
  padding: 295px;
  background-image: url('../assets/images/background1.jpg');
  background-size: cover;
  color: #fff;
  font-family: "Microsoft Yahei";
}

.title {
  font-size: 32px;
  color: #fff;
  margin-bottom: 20px;
  text-shadow: 0 2px 2px rgba(0, 0, 0, 0.3);
}

.form-container {
  border: 1px solid rgba(255, 255, 255, 0.3);
  padding: 100px;
  border-radius: 100px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
  background-color: rgba(255, 255, 255, 0.2);
}

.submit-button {
  width: 200px;
  background-color: #fff;
  color: #333;
  border: none;
  box-shadow: 0 2px 2px rgba(0, 0, 0, 0.3);
}

.submit-button:hover {
  background-color: #f0f0f0;
  color: #333;
}
</style>