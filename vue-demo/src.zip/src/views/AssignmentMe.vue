<template>
    <el-form 
    :inline="true" 
    :model="assignment" 
    label-width="100px" 
    ref="form"
    margin="0 auto"
    class="assign-form">
      <div id="AssignM"><h1>{{this.tableData.Sname}}的作业</h1></div>

      <el-row>
          <el-button type="primary" plain @click="addAssignment">添加作业</el-button>
          
        </el-row>
        <el-dialog title="添加作业" :visible.sync="addAssignmentVisible" width="50%">
          <el-form ref="form" :model="assignment" label-width="120px" class="form-container">

            <el-form-item label="作业名称">
              <el-input v-model="assignment.Aname" placeholder="请输入作业名称"></el-input>
            </el-form-item>

            <el-form-item label="截止时间">
              <el-date-picker v-model="assignment.Deadline" type="datetime" placeholder="选择日期时间"></el-date-picker>
            </el-form-item>

            <el-form-item label="描述信息">
              <el-input v-model="assignment.Context" type="textarea" placeholder="请输入描述信息"></el-input>
            </el-form-item>

          <el-row>
            <el-form-item>
              <el-button type="primary" @click="addAssignment" >提交</el-button>
              <el-button type="primary" @click="addAssignmentVisible = false" >取消</el-button>
            </el-form-item>
          </el-row>
            
          </el-form>
        </el-dialog>
      
         <el-table
                :data="tableData"
                style="width: 100%"
                :row-class-name="tableRowClassName"
                @selection-change="handleSelectionChange" stripe>
            <el-table-column
                    type="selection"
                    width="55">
            </el-table-column>
            <el-table-column
                    type="index"
                    width="50">
            </el-table-column>
  
  
            <el-table-column prop="Aname" label="作业名" align="center"></el-table-column>
  
            <el-table-column prop="Deadline" label="截止时间" align="center"></el-table-column>
  
            <el-table-column prop="Status" align="center" label="查看提交情况">
              <el-button type="success" @click="checksubmit">查看提交情况</el-button>
            </el-table-column>
  
            <el-table-column prop="operate" align="center" label="操作">                 
              <el-button type="danger" @click="DelAssign(this.Cname,item.Aname)">删除作业</el-button>       
              <el-button type="primary" @click="DelAssign(item.Aname)">修改作业</el-button>            
            </el-table-column>
        </el-table>
        
     </el-form>
  
    
  </template>
  
  <script>
  import axios from 'axios';
  
  
  export default {
    name:'AssigM',
    created() {
        const Assign = JSON.parse(localStorage.getItem('assignment'))
        this.Cname = JSON.parse(localStorage.getItem('Coursename'))
        console.log(" 哈哈哈  ",Assign)
        //this.tableData = Assign
        console.log(" 哈哈哈  ",this.tableData)
      },
    data() {
      return {
        addAssignmentVisible:false,
        Cname:'',
        assignment:{
            Aname:'',
            Deadline:'',
            //所有的与时间有关的都要修改   +入时间函数
            Status:'',
            Context:'',
        },
        FormData:new FormData(),
        tableData:[{
            Aname:'实验一',
            Deadline:'2023-06-01',
            Status:''
        }],
      };
    }, 
    methods: {  
    checksubmit(){
        window.location.href = '/studentassign';
    },
    addAssignment(){
        this.addAssignmentVisible = true;
    },
    DelAssign(Cname,Aname){
        this.FormData.append(Cname)
        this.FormData.append(Aname)
        axios({
            method:'post',
            url:'',
            data:this.FormData
        }).then(res=>res.data).then(res=>{
            if (res.succession === 'true'){
                alert("删除成功")
            }else{
                alert("删除失败")
            }
        })
    }    
  }
}
  </script>
  
  