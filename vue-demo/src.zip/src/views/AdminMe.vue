<template>
    <div>
        <h1>这是管理员页面</h1>
    </div>
</template>

<script>
export default{

}
</script>

<script setup>
</script>