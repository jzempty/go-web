<template>
    <div>
     
      <h1>这里是HOME分页</h1>
     
    </div>
  </template>
   
  <script>
   
  export default {
   
  };
   
  </script>
   
  <style>
  </style>