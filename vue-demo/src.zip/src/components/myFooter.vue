<template>
    <div style="background-color: white; color: black;height: 3rem; width: 100%;z-index: 999">
        <div style="height: 3rem;text-align: center;font-size: 14px">
            <i class="el-icon-user"></i>2020 JavaEE 大作业 感谢查看
        </div>
    </div>
</template>

<script>
    export default {
        name: "myFooter"
    }
</script>

<style scoped>

</style>