import axios from 'axios';

const api = {
  async getAssignments() {
    try {
            const response = await axios.get('/assignments');
            return response.data;
        } catch (error) {
            console.error(error);
            throw new Error('获取作业时发生了错误。');
        }
  },
  
  async submitAssignment(assignmentId) {
    try {
          await axios.post(`/assignments/${assignmentId}/submit`);
          return;
      } catch (error) {
          console.error(error);
          throw new Error('提交作业时发生了错误。');
      }
  },
  
  // 添加更多的方法
};

export default api;